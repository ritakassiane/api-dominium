<?php wp_head(); ?>
<p>API Dominium</p>
<?php wp_footer(); ?>